import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Connection conexion = ConexionBD.obtenerConexion();
        boolean encontrado = false;

        if (conexion != null) {
            UsuarioDAO usuarioDAO = new UsuarioDAO(conexion);

            System.out.println("Usuarios actuales:");
            List<Usuario> usuarios = usuarioDAO.listarUsuarios();
            for (Usuario u : usuarios) {
                System.out.println(u);
            }

            Scanner scanner = new Scanner(System.in);

            System.out.print("\nIngrese nombre: ");
            String nombre = scanner.nextLine();

            System.out.print("Ingrese correo: ");
            String email = scanner.nextLine();

            try {
                String INSERT = "INSERT INTO usuarios (nombre, email) VALUES (?, ?)";
                PreparedStatement pstmt = conexion.prepareStatement(INSERT);
                pstmt.setString(1, nombre);
                pstmt.setString(2, email);
                int filasInsertadas = pstmt.executeUpdate();
                if (filasInsertadas > 0) {
                    System.out.println("\nUsuario insertado correctamente.");
                } else {
                    System.out.println("\nNo se pudo insertar el usuario.");
                }
            } catch (SQLException e) {
                System.out.println("Error al insertar usuario: " + e.getMessage());
            }

            System.out.println("\nLista de usuarios actualizada:");
            usuarios = usuarioDAO.listarUsuarios();
            for (Usuario u : usuarios) {
                System.out.println(u);
            }

            System.out.print("\nIngrese el ID del usuario que desea buscar: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            try {
                String sql = "SELECT * FROM usuarios WHERE id = ?";
                PreparedStatement pstmt = conexion.prepareStatement(sql);
                pstmt.setInt(1, id);
                ResultSet rs = pstmt.executeQuery();

                System.out.println("\nResultado de la búsqueda:");
                while (rs.next()) {
                    System.out.println("ID: " + rs.getInt("id"));
                    System.out.println("Nombre: " + rs.getString("nombre"));
                    System.out.println("Email: " + rs.getString("email"));
                    encontrado = true;
                }

                if (!encontrado) {
                    System.out.println("No se encontró ningún usuario con ese ID.");
                }
            } catch (SQLException e) {
                System.out.println("Error al realizar la búsqueda: " + e.getMessage());
            }

            System.out.print("\nIngrese el ID del usuario que desea actualizar: ");
            int idActualizar = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Ingrese el nuevo nombre: ");
            String nuevoNombre = scanner.nextLine();

            System.out.print("Ingrese el nuevo correo: ");
            String nuevoEmail = scanner.nextLine();

            try {
                String UPDATE = "UPDATE usuarios SET nombre = ?, email = ? WHERE id = ?";
                PreparedStatement pstmt = conexion.prepareStatement(UPDATE);
                pstmt.setString(1, nuevoNombre);
                pstmt.setString(2, nuevoEmail);
                pstmt.setInt(3, idActualizar);

                int filasAfectadas = pstmt.executeUpdate();

                if (filasAfectadas > 0) {
                    System.out.println("\nUsuario actualizado correctamente.");

                    System.out.println("\nLista de usuarios actualizada:");
                    usuarios = usuarioDAO.listarUsuarios();
                    for (Usuario u : usuarios) {
                        System.out.println(u);
                    }
                } else {
                    System.out.println("\nNo se encontró un usuario con ese ID.");
                }
            } catch (SQLException e) {
                System.out.println("Error al actualizar usuario: " + e.getMessage());
            }

            System.out.println("Ingrese el ID del usuario que desea eliminar");
            int idEliminar = scanner.nextInt();
            scanner.nextLine();

            try {
                String DELETE = "DELETE FROM usuarios WHERE id = ? ";
                PreparedStatement pstmt = conexion.prepareStatement(DELETE);

                pstmt.setInt(1, idEliminar);
                int filasEliminadas = pstmt.executeUpdate();

                if (filasEliminadas > 0) {
                    System.out.println("Usuario eliminado correctamente");

                    System.out.println("\nLista de usuarios actualizada:");
                    usuarios = usuarioDAO.listarUsuarios();
                    for (Usuario u : usuarios) {
                        System.out.println(u);
                    }
                } else
                    System.out.println("Ocurrio un error en el proceso de eliminado");
            } catch (SQLException e) {
                System.out.println("Error al eliminar usuario: " + e.getMessage());
            }

            try {
                conexion.close();
                System.out.println("\nConexión cerrada correctamente.");
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
            }

            scanner.close();
        } else {
            System.out.println("No se pudo establecer la conexión.");
        }

    }
}