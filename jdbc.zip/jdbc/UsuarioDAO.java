import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {
    private Connection conexion;

    public UsuarioDAO(Connection conexion) {
        this.conexion = conexion;
    }

    public List<Usuario> listarUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT id, nombre, email FROM usuarios";
        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("id"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setEmail(rs.getString("email"));
                usuarios.add(usuario);
            }

            if (usuarios.isEmpty()) {
                System.out.println("No hay usuarios registrados en la base de datos.");
            } else {
                System.out.println("Lista de usuarios:");
                for (Usuario usuario : usuarios) {
                    System.out.println(usuario);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error al listar usuarios: " + e.getMessage());
        }

        return usuarios;
    }

    public boolean crearUsuario(Usuario usuario) {
    String sql = "INSERT INTO usuarios (nombre, email) VALUES (?, ?)";
    try (PreparedStatement stmt = conexion.prepareStatement(sql)) {
        stmt.setString(1, usuario.getNombre());
        stmt.setString(2, usuario.getEmail());

        int filasAfectadas = stmt.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Usuario creado correctamente: " + usuario.getNombre());
            return true;
        } else {
            System.out.println("No se pudo crear el usuario.");
        }

    } catch (SQLException e) {
        System.err.println("Error al crear usuario: " + e.getMessage());
    }

    return false;
}

}